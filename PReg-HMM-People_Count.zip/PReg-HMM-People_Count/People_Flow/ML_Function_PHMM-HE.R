#######################################################################################
#### Source Code for PHMM-HE: switch both intercept and slope ###
#### 1. PHMM_REG_ML.Package.Slope: Marginal likelihood (five sampling-based methods) for PHMM-HE
#### 2. PHMMREG_HE_summary: Simulation data and results for PHMM-HE (1 replicate)
#### 3. Parallel_submit_HE: Parallel computation for simulation PHMM-HE (350 replicate)
#### 4. BIC_result_slope/BIC: BIC calculation for PHMM-HEe
#######################################################################################

library(flexmix)  # for mixture Poisson regression #############
library(truncnorm) # for truncted normal data

#### Function 1. PHMM_REG_ML.Package.Slope: Marginal likelihood (five sampling-based methods) for PHMM-HE
PHMM_REG_ML.Package.Slope <- function(x,covamatrix ,L,burnin,maxiter,  results, prior)
{ NUM<-length(x)
  ## initial values for MCMC after burning 
  NITR=maxiter -burnin 
  sn= min(200, maxiter-burnin )  # Importance sampling
  ncovar =  max( dim(covamatrix)[2],1)   # number of covariates
  nbeta= ncovar+1             # number of parameters in one component
  nparam = (1+L)*(ncovar+1)          # number of parameters in model
  
  ## Prior information - hyperparameter 
  b00=0  # prior for coefficient mean
  B0=prior$sigma00  # prior for coefficient variance
  a0sai=prior$a00        # prior for sai transition matrix a00 and b00 and also for eta (prior for probability with L>1)
  b0sai=prior$b00   
  etaprior= 4
 
  ### Read MCMC result ##
  S0 = rep(0, NITR )   
  S =  ifelse(results$mcmc$SM.mcmc==1, 0, 1 )   
  SM = results$mcmc$SM.mcmc-1 

  
  beta00 =matrix(NA, nrow=NITR, ncol=nbeta) ;    beta00[, 1]= results$mcmc$beta0.mcmc[,1]
  beta10 =matrix(NA, nrow=NITR, ncol=nbeta*L ) ; for (i in 1:L){ beta10[, (i-1)*(nbeta)+1] = results$mcmc$beta0.mcmc[,i+1]   }
  for (j in 1:ncovar ){
    beta00[, j+1]=results$mcmc$beta1.mcmc[,(j-1)*(L+1)+1]  
    
    for  (i in 1:L){
      beta10[, (i-1)*(nbeta)+j+1 ] = results$mcmc$beta1.mcmc[,(j-1)*(L+1)+1 +i ]}
  }
  
  sai =results$mcmc$sai.mcmc 
  pcp = if(L==1) { matrix(1, ncol=L, nrow= maxiter-burnin )} else { results$mcmc$prop.mcmc[, -1]/(1-results$mcmc$prop.mcmc[, 1])  }
  ylag_P = results$mcmc$ylag.mcmc
  
  ### For beta parameter ###########
  b0_null = beta00 
  B0_null = matrix(rep(diag(var(beta00)), maxiter-burnin ), ncol=nbeta, byrow=T) 
  b10 = beta10
  B1  =  matrix( rep(diag(var(beta10) ), (maxiter-burnin)  ) , ncol=nbeta*L, byrow=T)
    
  ####calculate 2 by 2 table##
  N00T<-rep(NA, NITR); N01T<-rep(NA, NITR)
  N10T<-rep(NA, NITR); N11T<-rep(NA, NITR)
  N00T[1]<-0; N01T[1]<-0 ;N10T[1]<-0 ;N11T[1]<-0
  for ( I in 1:(NITR)){
    N00=0
    N01=0
    N11=0
    N10=0
    # the initial status
    if (S0[I]==0 & S[I,1]==0) {N00=N00+1}
    if (S0[I]==0 & S[I,1]==1) {N01=N01+1}
    if (S0[I]==1 & S[I,1]==0) {N10=N10+1}
    if (S0[I]==1 & S[I,1]==1) {N11=N11+1}
    for (II in 1:(NUM-1)){
      if (S[(I),II]==0 & S[(I),(II+1)]==0 ) {N00=N00+1}
      if (S[(I),II]==0 & S[(I),(II+1)]==1 ) {N01=N01+1}
      if (S[(I),II]==1 & S[(I),(II+1)]==0 ) {N10=N10+1}
      if (S[(I),II]==1 & S[(I),(II+1)]==1 ) {N11=N11+1}
    }
    N00T[(I)]=N00
    N01T[(I)]=N01
    N10T[(I)]=N10
    N11T[(I)]=N11
  } 
  
  ####calculate totla # in each component of mixture non-null state##
  Ns<-matrix(NA,nrow=NITR,ncol=L); Ns[1,]<-rep(0,L)
  for ( I in 1:(NITR)){
    Ns_T<-rep(0,L)
    for (K in 1:L){
      Ns_T[K]<-sum(SM[(I),]==K)
    }
    Ns[I, ] <- Ns_T+etaprior
  }
  ####calculate estimated Marginal Likelihood (ML)## 
  diff<-1;ptol<- 0.001 ; pbs_new1<-NULL
  qv<-rep(NA, NITR);pyv<-rep(NA, NITR);pvl_p<-rep(NA, NITR);pvm_p<-rep(NA, NITR);pys<-rep(NA, NITR);qv_p<-matrix(NA, nrow=NITR, ncol=sn)
  qvL<-rep(NA, NITR);pyv_L<-rep(NA, NITR);qv_L<-matrix(NA, nrow=NITR, ncol=sn)
  
  qn<-sample(1:NITR, sn, replace=F)
  N11<-N00T; N12<-N01T; N21<-N10T; N22<-N11T
  
  qv_2log<-rep(NA, NITR);qv_p_2log<-matrix(NA, nrow=NITR, ncol=sn)
  qvL_2log<-rep(NA, NITR);qv_L_2log<-matrix(NA, nrow=NITR, ncol=sn)
  qv_diff<-matrix(NA, nrow=NITR, ncol=sn) ; qvL_diff<-matrix(NA, nrow=NITR, ncol=sn)
  #####################################################################################
  cova_x <- matrix(c(rep(1, NUM), covamatrix  ), nrow=NUM, ncol=nbeta, byrow = F  )
  ######################################################################################  
  
  for (j in 1:NITR){ 
    num_L<-sample(qn, 1, replace=T) 
    sai_11<-rbeta(1, a0sai+N11[num_L], b0sai+N12[num_L])  #Transition matrix
    sai_22<-rbeta(1, a0sai+N22[num_L], b0sai+N21[num_L])  #Transition matrix
    sai_12<-1-sai_11
    sai_21<-1-sai_22
    
    p_L<-sai_21/(sai_12+sai_21) #prob for 0's
    pcp_T<-rdirichlet(1, Ns[num_L,] )    #probs for non-null state
    
    # sample the null Regression parameter
    betavar0_T <- rmvnorm(n =1, mean=b0_null[num_L,] , sigma= diag(B0_null[num_L,])  ) 
    
    # sample the non-null Regression parameter
    betavar1_T<-matrix(NA, nrow=L, ncol=nbeta )
    for (K in 1:L){
      betavar1_T[K, ]<-rmvnorm(n =1, mean=b10[num_L,(1+nbeta*(K-1)) :( nbeta*K)], sigma= diag(B1[num_L,(1+nbeta*(K-1)) :( nbeta*K)]) )  
    }
    
    ## the forward filtering for IS 
    Spred_L<-matrix(rep(0, NUM*2), NUM, 2, byrow=T)
    Sprob_L<-matrix(rep(0, NUM*2), NUM, 2, byrow=T)
    Ssmth_L<-matrix(rep(0, NUM*2), NUM, 2, byrow=T)
    S0smth_L<-matrix(rep(0, NITR*2),NITR, 2, byrow=T)
    S0smth_L[1,1]=0
    S0smth_L[1,2]=1
    ##density##
    ylag_L<-rep(NA, NUM)
    mean.null<-exp( cova_x %*% t(betavar0_T) )
    f0x_L<-dpois(x, lambda=mean.null) 
    
    pmix_L<-matrix(0,nrow=NUM, ncol=L) 
    f1x_L<-0
    for (K in 1:L){
      mean.nonnull<-exp( cova_x %*% matrix(betavar1_T[K, ], nrow=nbeta, ncol=1) )
      mean.nonnull<-ifelse (mean.nonnull <0, 0, mean.nonnull )
      pmix_L[,K]<-pcp_T[K]*dpois(x,lambda= mean.nonnull )
      f1x_L<-f1x_L+pmix_L[,K]
    }
    ### slove f0x=0 and f1x=0 case ##
    f0x_L.a= ifelse(f0x_L == 0,  1e-300, f0x_L )
    f1x_L.a= ifelse(f1x_L == 0,  1e-300, f1x_L )
    f0x_L.a= ifelse(f0x_L + f1x_L < 1e-300, mean(f0x_L ),f0x_L.a  )
    f0x_L  = f0x_L.a; f1x_L =f1x_L.a;
    
    Spred_L[1,1]=sai_11*p_L+sai_21* (1-p_L)
    Spred_L[1,2]=sai_12*p_L+sai_22*(1-p_L)
    ylag_L[1]=f0x_L[1]*Spred_L[1,1]+f1x_L[1]*Spred_L[1,2]
    Sprob_L[1,1]= f0x_L[1]*Spred_L[1,1]/ylag_L[1]
    Sprob_L[1,2]= f1x_L[1]*Spred_L[1,2]/ylag_L[1]
    
    for ( K in 2:NUM){
      Spred_L[K,1]=sai_11*Sprob_L[(K-1),1]+sai_21*Sprob_L[(K-1),2]
      Spred_L[K,2]=sai_12*Sprob_L[(K-1),1]+sai_22*Sprob_L[(K-1),2]
      ylag_L[K]=f0x_L[K]*Spred_L[K,1]+f1x_L[K]*Spred_L[K,2]
      Sprob_L[K,1]= f0x_L[K]*Spred_L[K,1]/ylag_L[K]
      Sprob_L[K,2]= f1x_L[K]*Spred_L[K,2]/ylag_L[K]
    }
    
    for (i in 1:sn) {
      qv_mean2<- 0  ; qv_mean2_L <-0; 
      for (K in 1:L){
        pickm<-(1+nbeta*(K-1)) :( nbeta*K)
        qv_mean2 <- qv_mean2 + dmvnorm( c(beta10[j,pickm] ) , mean=b10[qn[i], pickm],sigma=diag(B1[qn[i],pickm]),log=T )
        qv_mean2_L<- qv_mean2_L + dmvnorm(betavar1_T[K,], mean=b10[qn[i], pickm],sigma=diag(B1[qn[i],pickm]),log=T )
      }
      qv_p_2log[j,i]<- dbeta(sai[j,1], a0sai+N11[qn[i]], b0sai+N12[qn[i]],log=T) + dbeta(sai[j,4], a0sai+N22[qn[i]], b0sai+N21[qn[i]], log=T) +
        dmvnorm(beta00[j,] ,mean=b0_null[qn[i],] ,sigma=diag(B0_null[qn[i],]), log=T)+ qv_mean2 + ddirichlet(matrix(c(pcp[j,]),1,L), Ns[qn[i],], log=T)
      
      qv_L_2log[j,i]<- dbeta(sai_11, a0sai+N11[qn[i]], b0sai+N12[qn[i]], log=T) + dbeta(sai_22, a0sai+N22[qn[i]], b0sai+N21[qn[i]],log=T) +
        dmvnorm(betavar0_T,mean=b0_null[qn[i],] ,sigma=diag(B0_null[qn[i],]), log=T)+ qv_mean2_L + ddirichlet(matrix(c(pcp_T),1,L), Ns[qn[i],], log=T)
    }
    
    qmcmax =max(qv_p_2log[j ,])
    qqmax=max(qv_L_2log[j ,])
    
    for ( i in 1:sn){
      qv_diff[j,i] <-max(qv_p_2log[j,i]-qmcmax, -1e300)
      qvL_diff[j,i]<-max(qv_L_2log[j,i]-qqmax, -1e300)
    }
    
    qv_2log[j ]<-qmcmax+log(mean(exp(qv_diff[j , ])) )
    qvL_2log[j ]<-qqmax+log(mean(exp(qvL_diff[j , ] )))  
    
    probtemp<-sai[j,3]/(sai[j,2]+sai[j,3]) #probability for 0's
    
    pyv[j]<-sum( log( ylag_P[j, ] ))
    pyv_L[j]<-sum(log( ylag_L ))
    pvl_p[j]<- dmvnorm(betavar0_T,mean=rep(b00, nbeta) ,sigma=diag(B0,nbeta,nbeta), log=T) + sum(dmvnorm(betavar1_T,mean=rep(b00, nbeta) ,sigma=diag(B0,nbeta,nbeta), log=T))+
      log(dbeta(sai_11, a0sai, b0sai))+log(dbeta(sai_22, a0sai, b0sai))+log(ddirichlet(matrix(c(pcp_T),1,L), rep(etaprior,L)) )
    
    pvm_p[j]<- dmvnorm(c(beta00[j,] ) ,mean=rep(b00, nbeta)  ,sigma=diag(B0,nbeta,nbeta), log=T) + sum(dmvnorm(matrix(c(beta10[j,]), nrow=L, ncol=nbeta, byrow=T),mean=rep(b00, nbeta)  ,sigma=diag(B0,nbeta,nbeta), log=T))+
      log(dbeta(sai[j,1], a0sai, b0sai ))+log(dbeta(sai[j,4], a0sai, b0sai ))+log(ddirichlet(matrix(c(pcp[j,]),1,L), rep(etaprior,L)) )
    
    pys[j]<- dmvnorm(c(beta00[j,] ) ,mean=rep(b00, nbeta) ,sigma=diag(B0,nbeta,nbeta), log=T) +
      sum(dmvnorm(matrix(c(beta10[j,]), nrow=L, ncol=nbeta, byrow=T) ,mean=rep(b00, nbeta) ,sigma=diag(B0,nbeta,nbeta), log=T) )+
      sum(dpois(x[SM[j,]== 0], lambda=exp( cova_x[SM[j,]== 0, ] %*% matrix(c(beta00[j,]),nrow=nbeta,ncol=1)),log=T ))+
      sum(apply(data.frame(K=c(1:L)), 1,function(K) sum( dpois(x[SM[j,]== K], lambda=exp( cova_x[SM[j,]== K, ] %*% matrix(c(beta10[j,(1+nbeta*(K-1)) :( nbeta*K)] ),nrow=nbeta,ncol=1)),log=T))) )-
      dmvnorm(c(beta00[j,] ) ,mean=b0_null[j,] ,sigma=diag(B0_null[j,]), log=T) -
      sum(apply(data.frame(K=c(1:L)), 1, function(K) dmvnorm( c(beta10[j,(1+nbeta*(K-1)) :( nbeta*K)] ) ,mean=b10[j,(1+nbeta*(K-1)) :( nbeta*K)] ,sigma=diag(B1[j,(1+nbeta*(K-1)) :( nbeta*K)]), log=T) ))
  } 
  
  ratio2=pyv_L+pvl_p-qvL_2log
  ratio2max=max(ratio2, na.rm =T)
  
  ratio3=qv_2log-pyv-pvm_p
  ratio3max=max(ratio3, na.rm =T)
  
  ratio4=-1*pyv
  ratio4max=max(ratio4, na.rm =T)
  
  ratio5=-1*pys
  ratio5max=max(ratio5, na.rm =T)
  
  pis_2=ratio2max+log(mean(exp(ratio2-ratio2max), na.rm=T))
  pri_3=-1*(ratio3max+log(mean(exp(ratio3-ratio3max), na.rm=T)))
  phm_4=-1*(ratio4max+log(mean(exp(ratio4-ratio4max), na.rm=T)))
  phm2_5=-1*(ratio5max+log(mean(exp(ratio5-ratio5max), na.rm=T)))   
  
  if (pis_2 == -Inf | is.na(pis_2) | is.na(pri_3)|is.na(phm_4)|is.na(phm2_5) )
  {
    data2<-data.frame(L=L , pbs_new1=0, pis_2=0,pri_3=0,phm_4=0,phm2_5=0) 
    
  }else{
    
    pbs_new=pis_2
    loop.int=0
    while(diff>ptol & loop.int< maxiter)
    { loop.int = loop.int+1 
    pbs_old<-pbs_new
    Aratio=pyv_L+pvl_p-log(NITR*exp(qvL_2log)+NITR*exp(pyv_L+pvl_p-pbs_old) ) ; Aratio= Aratio[is.infinite(Aratio)==F ]
    Amax=max(Aratio, na.rm=T)
    
    Bratio=qv_2log-log(NITR*exp(qv_2log)+NITR*exp(pyv+pvm_p-pbs_old) ) ; Bratio= Bratio[is.infinite(Bratio)==F ]
    Bmax=max(Bratio, na.rm=T)
    
    A=Amax+log(mean(exp(Aratio-Amax), na.rm=T)) 
    B=Bmax+log(mean(exp(Bratio-Bmax), na.rm=T))
    
    pbs_new<-min(A-B,0 , na.rm =T) 
    
    diff<-abs(pbs_old-pbs_new)
    pbs_new1<-pbs_new
    }

    data2<-data.frame(L=L , pbs_new1=pbs_new1, pis_2=pis_2,pri_3=pri_3,phm_4=phm_4,phm2_5=phm2_5) 
  }
  
  return(data2)
}


#### Function 2. PHMMREG_HE_summary: Simulation data and results for PHMM-HE (1 replicate)
PHMMREG_HE_summary<- function (ii,L=1, NUM = 3000, burnin=3000, maxiter=5000, THIN=1, pii=c(1,0), pc=1, A=matrix(c(0.95, 0.05, 0.2, 0.80), 2, 2, byrow=T),
                                f0beta=c(1, -0.5) , beta10_fixed =matrix(c(2, -0.5), ncol=1,nrow=2), beta_all=seq(2,3.2, by=0.2), prob1=0.5   )
{
  ncovar <- length(f0beta) -1  #number of covariate 
  tL=dim(beta10_fixed)[2]      # True L
  
  beta_update= rep(beta_all,each=50) [ii]
  f1beta = beta10_fixed

  if(ncovar==1 & tL==1 ){
    f1beta[length(f0beta),1]  = beta_update
    set.seed(2468+ii)
    Z<-rbinom(NUM, size=1,prob=0.5) 
    set.seed(2468+ii)
    sim.data<-rdata1.PoissonZ.hmm(NUM, pii, A, f0beta, f1beta, Z)
    x=sim.data$o  ; covamatrix=matrix(Z,nrow=length(x) , byrow=F  )   }
  if(ncovar==1 & tL==2 ){
    f1beta[2,2]  = beta_update
    set.seed(2468+ii)
    Z<-rbinom(NUM, size=1,prob=0.5) 
    set.seed(2468+ii)
    sim.data<-rdata.PoissonZ.hmm(NUM, pii,A, f0beta, pc,f1beta, Z)
    x=sim.data$o  ; covamatrix=matrix(Z,nrow=length(x) , byrow=F  )   }
  
  if(ncovar==1 & tL==1 ){
    f1beta[2,1] = beta_update  
    set.seed(2468+ii)
    Z<- rtruncnorm(NUM, a=-2, b=2, mean = 0, sd = 1)   
    set.seed(2468+ii)
    sim.data<-rdata.PoissonZ.hmm(NUM, pii,A, f0beta, pc,f1beta, Z) 
    x=sim.data$o  ; covamatrix=matrix(Z,nrow=length(x) , byrow=F  )   }
  
  if(ncovar==2 & tL==1) {
    f1beta[2,1] = beta_update 
    set.seed(1234+2*ii)
    Z1<-rtruncnorm(NUM, a=-2, b=2, mean = 0, sd = 1)  
    set.seed(1234+ 3*ii)
    Z2<- rbinom(NUM, size=1,prob=0.5)  
    Z=cbind( Z1, Z2)
    
    set.seed(1234+3*ii)
    sim.data<-rdata.PoissonZ.hmm(NUM, pii,A, f0beta, pc,f1beta, Z)   
    x=sim.data$o  ; covamatrix=matrix(Z,nrow=length(x) , byrow=F  )   }

  if(ncovar==2 & tL==2) {
    f1beta[2,2] = beta_update 
    set.seed(1234+3*ii)
    Z1<-rtruncnorm(NUM, a=-2, b=2, mean = 0, sd = 1)  
    set.seed(1234+ 2*ii)
    Z2<- rbinom(NUM, size=1,prob=0.5)  
    Z=cbind( Z1, Z2)
    
    set.seed(1234+3*ii)
    sim.data<-rdata.PoissonZ.hmm(NUM, pii,A, f0beta, pc,f1beta, Z)   
    x=sim.data$o  ; covamatrix=matrix(Z,nrow=length(x) , byrow=F  )   }
  
  ##### MCMC ##############
  INI<-list()
  m2 <- stepFlexmix(x ~ covamatrix,  model = FLXMRglm(family = "poisson"),  control = list(minprior=0.01), k = L+1, nrep = 5)
  INI$beta0_ini<-rep(NA, L+1)
  INI$beta1_ini<-rep(NA, (L+1)*ncovar )
  
  for (i in 1:(L+1)){
    INI$beta0_ini[i]  = parameters(m2, component = which(rank(-prior(m2))==i), model = 1) [1]
    for (j in 1:ncovar){
      INI$beta1_ini[(j-1)*(L+1)+i]  = parameters(m2, component = which(rank(-prior(m2))==i), model = 1) [j+1]}}
  
  INI$pi0_ini=c(0.5, 0.5)
  INI$sai_ini=matrix(c(0.8, 0.2, 0.4, 0.6), nrow=2, ncol=2, byrow=TRUE)
  
  prior<-list()
  prior$sigma00=100  # prior for coefficient variance
  prior$a00=2        # prior for sai transition matrix a00 and b00 
  prior$b00=1        
  #THIN=THIN
  q=0.1
  BURNIN=burnin
  NITR=maxiter
  tuning=rep(0.15, (L+1)*(ncovar+1))
  if(ncovar==0 & tL==1 ) { tuning= rep(0.15, 1+L+1)}  
  if(ncovar==0){ ncovar=1} else { ncovar=ncovar }
  factor =1
  
  set.seed(2468+ii)
  results_n =BayesPoiZSlope(X=x, Z=covamatrix, L=L, COL=ncovar,NITR=NITR, THIN=THIN, BURNIN=BURNIN, tuning=tuning, INI=INI, prior=prior, q=q,factor=factor, mcmethod=2)
 
  ### ML ###########
  set.seed(2468+ii)
  ML_n =PHMM_REG_ML.Package.Slope(x ,covamatrix, L,burnin/THIN,maxiter/THIN,  results_n, prior)
  BIC_n = BIC_result_slope(x,covamatrix, L=L, results=results_n)

  #### Get 2*2 table ###########################;
  bayes.de<-results_n$bayes.de
  N00.BAY<-sum(bayes.de[sim.data$s ==0]==0)
  N10.BAY<-sum(bayes.de[sim.data$s ==0]==1)
  N01.BAY<-sum(bayes.de[sim.data$s ==1]==0)
  N11.BAY<-sum(bayes.de[sim.data$s ==1]==1)
  
  if(L==1){
    data2 = data.frame(ii=ii,Case=beta_update,  ML_n, BIC_n, N00.BAY, N10.BAY, N01.BAY, N11.BAY,  data.frame(t(unlist(results_n$par.mean[-length(results_n$par.mean)] )))  )
  } else {   data2 = data.frame(ii=ii,Case=beta_update,  ML_n, BIC_n, N00.BAY, N10.BAY, N01.BAY, N11.BAY,  data.frame(t(unlist(results_n$par.mean[-length(results_n$par.mean)])))  )  }

  return(data2 ) 
}

#### Function 3. Parallel_submit_HE: Parallel computation for simulation PHMM-HE (350 replicate)
Parallel_submit_HE <- function ( L=1, NUM = 3000, burnin=5000, maxiter=10000,THIN=10, pii=c(1,0), pc =1, A=matrix(c(0.95, 0.05, 0.2, 0.80), 2, 2, byrow=T),
                                      f0beta=c(2, 0.25 , -0.25) , beta10_fixed =matrix(c(2, 0.25 , -0.25), ncol=1, nrow=3), beta_all=seq(2,3.2, by=0.2), prob1=0.5,
                                      pastename=20200508, subname ="a",startn=1,tot_nrow=350, ncore =8, Funname= Funname )
{
  start.time <- Sys.time()
  
  ncovar <- length(f0beta) -1  #number of covariate 
  tL=dim(beta10_fixed)[2]  
  L_true=paste("L", tL, collapse = NULL, sep = "" )
  
  if (ncovar!=0){
    totncol =19+(L+1)*(ncovar+1)  } else {  totncol = 19+(L+1)*(1+1) }
  Runfun = PHMMREG_HE_summary 
  
  ncore <- ncore 
  cl<-makeCluster(ncore)
  registerDoParallel(cl)
  
  Results_n = data.frame(matrix(NA, ncol= totncol, nrow =c( tot_nrow-startn+1)) )
  Results_n = foreach(ii=startn:tot_nrow,.combine=rbind, .packages=c("HMMtesting","DirichletReg", "CholWishart","mvtnorm", "matrixcalc","Rlab","flexmix","truncnorm"), .export= Funname )  %dopar% Runfun(ii, L=L,NUM=NUM, burnin=burnin ,maxiter=maxiter, THIN=THIN ,pc =pc, f0beta = f0beta, prob1=prob1,beta10_fixed =beta10_fixed, beta_all=beta_all  )
  
  stopCluster(cl)
  write.csv(Results_n,file= paste( "PHMM_HE_Estimate_", L_true,L,"_", subname, "_",pastename, ".csv", collapse = NULL, sep = "" ) )
  
  end.time <- Sys.time()
  #### Save simulation time #########
  sink( paste( "Sim.time_", model ,"_Estimate_", L_true,L,"_", subname, "_",pastename, ".txt", collapse = NULL, sep = "") )
  print( time.taken <- end.time - start.time  )
  sink()
  return(Results_n ) 
}



#### Function 4. BIC_result_slope/BIC: BIC calculation for PHMM-HEe
BIC<-function(f0x, f1x, S0, S,A, pi0,npar){
  # f0x: the density under null
  # f1x: the density under nonnull
  # S0: the initial state
  # S:  the sequence of decisions
  # A: tansitional matrix
  # pi0: the stationary distribution
  # npar: the number of parameters
  
  NUM<-length(f0x)
  # the density corresponding to the sampled states
  FDIC=rep(0, NUM)
  for ( i in 1: NUM){
    if (S[i]==0) {FDIC[i]=f0x[i]} else {
      FDIC[i]=f1x[i]}
  }
  
  # the transitional probability based on the sampled states
  ADIC=rep(0, NUM)
  if (S0==1){
    ADIC0=pi0[2]} else{
      ADIC0=pi0[1]}
  
  if ((S0==0)&(S[1]==0)) {ADIC[1]=A[1,1]}
  if ((S0==0)&(S[1]==1)) {ADIC[1]=A[1,2]}
  if ((S0==1)&(S[1]==0)) {ADIC[1]=A[2,1]}
  if ((S0==1)&(S[1]==1)) {ADIC[1]=A[2,2]}
  
  for ( i in 1: (NUM-1)){
    if ((S[i]==0)&(S[i+1]==0)) {ADIC[i+1]=A[1,1]}
    if ((S[i]==0)&(S[i+1]==1)) {ADIC[i+1]=A[1,2]}
    if ((S[i]==1)&(S[i+1]==0)) {ADIC[i+1]=A[2,1]}
    if ((S[i]==1)&(S[i+1]==1)) {ADIC[i+1]=A[2,2]}
  }
  
  # calculate the likelihood
  BICTEMP=log(ADIC0)
  for ( i in 1: (NUM)){
    BICTEMP=BICTEMP+log(FDIC[i])+log(ADIC[i])
  }
  BIC=-2*BICTEMP+(npar)*log(NUM)
  return(BIC)
}
BIC_result_slope <- function(x,covamatrix, L, results){
  NUM = length(x)
  beta0 =results$par.mean$f0beta     
  mean.null<- exp(beta0[1] + covamatrix %*% beta0[-1])
  f0x<-dpois(x, lambda=mean.null   )
  
  nbeta= length(beta0); 
  beta1 =results$par.mean$f1beta  
  pcp=if(L==1){1} else{ apply(results$mcmc$prop.mcmc[, -1]/(1-results$mcmc$prop.mcmc[, 1]),2,mean)}
  pmix<-matrix(0,nrow=NUM, ncol=L) 
  f1x<-0
  for (K in 1:L){
    mean.nonnull<- exp( beta1[(1+nbeta*(K-1))] + covamatrix %*% beta1[(2+nbeta*(K-1)): (nbeta*K)] )
    pmix[,K]<-pcp[K]*dpois(x,lambda= mean.nonnull )
    f1x<-f1x+pmix[,K]
  }
  
  S0 = 0
  q=0.1
  bayes.de<-results$bayes.de 
  cat( sprintf("BAY method Detected NEG/Positive: %1.0f",  table(bayes.de ) ),"\n")
  S =bayes.de   
  A = matrix(results$par.mean$sai , nrow=2, ncol=2, byrow=T)
  pi0 = c(1, 0)
  npar = 2+nbeta + L*(nbeta +1)

  BIC_n=BIC(f0x, f1x, S0, S,A, pi0,npar)
  print(c(L, BIC_n))
  return(BIC_n)
}


