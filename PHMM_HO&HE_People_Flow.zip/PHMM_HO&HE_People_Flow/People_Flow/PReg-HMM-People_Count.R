
##########################################################################
########## PReg - HMM for  People count data set #################
##########################################################################

rm(list=ls(all=TRUE))
# set the work directory to where the data set file and source R file are
setwd("/path/to/the data/People_Flow")
library(HMMtesting) 
library(DirichletReg)
library(CholWishart)
library(mvtnorm)
library(flexmix)  # for mixture Poisson regression #############
source("ML_Function_PHMM-HO.r") ## source function for PHMM-HE


###### Data step #################
data1_1<-read.csv(file="CalIt2_Count.csv",sep = "," ,dec = "." )
mydata = data1_1;
mydata$weekend_day = ifelse(data1_1$weekday_n == 1 | data1_1$weekday_n == 7, 1, 0 )
mydata$Time_day_morning = ifelse(data1_1$Timeofday >=16 & data1_1$Timeofday<= 25, 1, 0    )
mydata$Time_day_After = ifelse(data1_1$Timeofday >=26 & data1_1$Timeofday<= 35, 1, 0    )
mydata$Time_day_Even = ifelse(data1_1$Timeofday >=36 & data1_1$Timeofday<= 45, 1, 0    )

peopleflow<-mydata
save(peopleflow, file="peopleflow.RData")
x= mydata$Count;
covamatrix = matrix(c(mydata$weekend_day, mydata$Time_day_morning,mydata$Time_day_After, mydata$Time_day_Even ), nrow=length(x), ncol=4 , byrow = FALSE)

####### 1. Function for PReg-HMM #############
PHMM_HO_Flow <- function (ii,x, covamatrix=matrix(Z,nrow=length(X) , byrow=F  ) ,L=1, COL=4,maxiter=5000, burnin=3000, THIN=1) {
  ncovar=COL
  ##### MCMC ##############
  set.seed(2468+ii)
  INI<-list()
  poi.fit<-glm(x~covamatrix, family=poisson)
  INI$beta00_ini=coef(poi.fit)[1]-abs(coef(poi.fit)[1])*0.5
  INI$beta1_ini=as.numeric(as.vector(coef(poi.fit)[2:(ncovar+1)]))
  # #### initial for beta10##############
  m2 <- stepFlexmix(x ~ covamatrix,  model = FLXMRglm(family = "poisson"),  control = list(minprior=0.01), k = L+1, nrep = 15)
  p.mean =rep(NA, L)
  for (i in 1:length(prior(m2)) ){p.mean[i] =parameters(m2, component = which(rank(-prior(m2))==i), model = 1) [1] }
  if (length(prior(m2)) <(L+1)  ) {for (I in (length(prior(m2))+1):(L+1)  ) {p.mean[I] =1 +I*0.05 } }
  p.mean = sort(p.mean )
  INI$beta01_ini = p.mean[-1] 
  
  INI$pi0_ini=c(0.5, 0.5)
  INI$sai_ini=matrix(c(0.8, 0.2, 0.4, 0.6), nrow=2, ncol=2, byrow=TRUE)
  prior<-list()
  prior$sigma00=100  # prior for coefficient variance
  prior$a00=2        # prior for sai transition matrix a00 and b00 
  prior$b00=1        
  THIN=THIN
  q=0.1
  BURNIN=burnin
  NITR=maxiter
  tuning= ifelse(L<5 ,rep(0.15, 1+L+ncovar), rep(0.025, 1+L+ncovar) )
  
  set.seed(2468+ii)
  results_n =BayesPoiZ(X=x, Z=covamatrix, L=L, COL=ncovar,NITR=NITR, THIN=THIN, BURNIN=BURNIN, tuning=tuning, INI=INI, prior=prior, q=q,mcmethod = 2)
  ### ML ###########
  set.seed(2468+ii)
  ML_n =PHMM_REG_ML.Package.Shared(x ,covamatrix, L,burnin,maxiter,  THIN,results_n, prior)
  BIC_n = BIC_result_shareslope(x,covamatrix, L=L, results=results_n)
  #### Get 2*2 table ###########################;
  bayes.de<-results_n$bayes.de
  print(table(bayes.de))
  data2 = list(ii=ii, results_n=results_n, ML=ML_n, BIC=BIC_n, de= table(bayes.de))
  return(data2 ) 
}

# posterior analysis

post.est<-function(data){
  mean<-mean(data)
  sd<-sd(data)
  out<-(cbind(mean, sd))
  colnames(out)<-c("mean","sd")
  return(out)
}
# mcmcoutput
mcmc.output<-function(output, L){
  mcmc<-output$results_n$mcmc
  par<-data.frame(name=character(),
                  mean=numeric(),
                  sd=numeric(),
                        stringsAsFactors=FALSE) 
  # beta0 intercept terms
  plot(ts(mcmc$beta00.mcmc), main=paste("beta00 Intercept under H0"))
  par[1,1]<-"beta00"
  par[1,2:3]<-post.est(mcmc$beta00.mcmc)  
  
  if (L==1){
    plot(ts(mcmc$beta01.mcmc), main=paste("beta01 Intercept under H1"))
    par[2,1]<-"beta01"
    par[2,2:3]<-post.est(mcmc$beta01.mcmc)  
    }else{
    for ( i in 1:L){    
      plot(ts(mcmc$beta01.mcmc[,i]), main=paste("beta01 Intercept under H1 Component", i))
      par[(i+1),1]<-paste("beta01-", i,sep="")
      par[(i+1),2:3]<-post.est(mcmc$beta01.mcmc[,i]) }
  }
    # for beta1.mcmc
  for (i in 1:4){plot(ts(mcmc$beta1.mcmc[,i]), main=paste("beta",i, sep=""))
    par[((L+1)+i),1]<-paste("beta", i, sep="")
    par[((L+1)+i),2:3]<-post.est(mcmc$beta1.mcmc[,i])}
  
  # for pi0 and for prop in the non-null state
  for (i in 1:(L+1))
    if (L==1){
  plot(ts(mcmc$pi0.mcmc[,i]), main=paste("prop", (i-1), sep=""))
  par[((L+5)+i),1]<-paste("prop", (i-1), sep="")
  par[((L+5)+i),2:3]<-post.est(mcmc$pi0.mcmc[,i])}else{
    plot(ts(mcmc$prop.mcmc[,i]), main=paste("prop", (i-1), sep=""))
    par[((L+5)+i),1]<-paste("prop", (i-1), sep="")
    par[((L+5)+i),2:3]<-post.est(mcmc$prop.mcmc[,i])
  }
  
  # for sai
  for (i in 1:4){plot(ts(mcmc$sai.mcmc[,i]), main=paste("sai",i, sep=""))
    par[((2*L+6)+i),1]<-paste("sai", i, sep="")
    par[((2*L+6)+i),2:3]<-post.est(mcmc$sai.mcmc[,i])}
  
  # return the data frame with posterior mean and std
  return(par)
}
##### Result: PReg-HMM ############

# change this number for different mixture structure in non-null
L=7 # number of mixture in nonnull

# run the mcmc and model selection criterian
maxiter=50000 ; burnin =15000; THIN=10
HO_L1=PHMM_HO_Flow(ii=1,x, covamatrix ,L=L, COL=4, maxiter,burnin, THIN)
str(HO_L1)

# check for convergence and posterior estimation
pdf(file=paste("HO_L", L,"plot_longer.pdf", sep=""), height = 8, width=16)
mcmc.output(HO_L1, L=L)
dev.off()

# save the mcmc and model selection results
save(HO_L1,file=paste("HO_L",L,".RData", sep=""))




